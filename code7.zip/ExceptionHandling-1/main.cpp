#include <iostream>

using namespace std;

/*
    Exception: Abnormal Condition or Runtime Error

    Handling:

    try {}
    catch() {}
    throw finally
*/

int main()
{
    cout<<"Exception Handling"<<endl;

    //char value = 'A';
    int value = 23;

    try {

        if(value == 23)
            throw 23;
        if(value == 'C')
            throw 'C';

        cout<<"Try - Block"<<endl;

    }

    catch(char e)
    {
        cout<<"Exception here "<<e<<endl;
    }

    catch(int e)
    {
        cout<<"Exception here"<<e<<endl;
    }

    cout<<"Outside the try and catch block"<<endl;

    return 0;
}
