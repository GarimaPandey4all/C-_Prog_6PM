#include <iostream>

using namespace std;

class Demo
{
public:
//    static method
    static void func()
    {
        cout<<"This is Static Method"<<endl;
    }
};

int main()
{
    Demo :: func(); //calling of static member method

    return 0;
}
