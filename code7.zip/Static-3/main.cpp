#include <iostream>

using namespace std;

class Counter {

public:
    void updateCount()
    {
        static int cnt; // by default static int cnt = 0;
        cout<<"Count is: "<<cnt++<<endl;
    }
};

int main()
{
    Counter obj;

    for(int i = 0; i < 5; i++)
    {
        obj.updateCount();
    }

    return 0;
}
