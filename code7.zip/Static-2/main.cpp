#include <iostream>

using namespace std;

class Student {
private:

    int rollno;
    static int marks;

public:
    void setData(int r)
    {
        rollno = r;
    }
    void getData()
    {
        cout<<rollno<<endl;
        cout<<marks<<endl;
    }
};

int Student :: marks = 546; //static variable initialized

int main()
{
    Student obj;
    obj.setData(40);
    obj.getData();

    return 0;
}
