#include <iostream>

using namespace std;

class Complex {

private:
    int a, b;

public:
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    void getData()
    {

        cout<<"a is: "<<a<<" b is"<<b<<endl;
    }

    friend void func(Complex); // It is the declaration of friend function

};

//friend function defined out side the class
void func(Complex obj)
{
    cout<<"Sum is: "<<obj.a + obj.b;
}


int main()
{

    Complex c1;
    c1.setData(10, 20);
    c1.getData();

    func(c1);

    return 0;
}
