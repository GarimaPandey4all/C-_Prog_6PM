#include <iostream>

using namespace std;


namespace first {
    int z = 600;
}

namespace second {
    int z = 300;
}

//global variable
//int z = 600;

int main()
{
    //local variable
    int z = 500;

    cout<<z<<endl;

    cout<<first::z<<endl;

    cout<<second::z<<endl;

    return 0;
}
