#include <iostream>

using namespace std;

class Shape {
public:
    void shape()
    {
        cout<<"Shape Class Method"<<endl;
    }
};

class Circle : public Shape {
public:
    //Override
    void shape()
    {
        cout<<"Circle Class Method"<<endl;
    }
};

int main()
{
    Circle obj;
    obj.shape();
    obj.shape();

    Shape obj2;
    obj2.shape();

    return 0;
}
