#include <iostream>

using namespace std;

/*
    Polymorphism: Many Forms

    Poly - many

    morphism - forms

    person: student, son, father, trainer, employee etc.....

    Polymorphism has two types:

    1. Compile Time Polymorphism
        a. Function Overloading
        b. Operator Overloading
    2. Runtime Polymorphism
        a. Overrriding

*/
//Function Overloading

class Overloading
{
public:

    void func()
    {
        int a;

        cout<<"Enter value for a:";
        cin>>a;
        cout<<"a is:"<<a<<endl;
    }

    void func(int x, int y)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
    }

    void func(int x, int y, int z)
    {
        cout<<"x is:"<<x<<endl;
        cout<<"y is:"<<y<<endl;
        cout<<"z is:"<<z<<endl;
    }

    void func(float z)
    {
        cout<<"z is:"<<z<<endl;
    }

};

int main()
{
    Overloading obj;

    obj.func();
    obj.func(10, 20);
    obj.func(10, 20, 30);
    obj.func(56.78f);

    return 0;
}
