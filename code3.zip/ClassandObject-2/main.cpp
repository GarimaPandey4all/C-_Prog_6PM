#include <iostream>

using namespace std;

class Basic {
public:

    void showData();
};

// return type classname :: functionname{} // :: - scope resolution operator
void Basic :: showData()
{
    cout<<"Hello World";
}

int main()
{
    Basic obj;
    obj.showData();

    return 0;
}
