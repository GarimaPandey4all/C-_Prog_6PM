#include <iostream>

using namespace std;

class Calculator {

public:
    int a, b; // instance variables

    void getData(int a, int b)
    {
        this->a = a; // instance variable = local variable
        this->b = b;
    }

    void showData()
    {
        cout<<"Addition: "<<(a + b)<<endl;
        cout<<"Subtraction: "<<(a - b)<<endl;
    }

};

int main()
{
    Calculator obj; // this - current object
    obj.getData(10, 20);
    obj.showData();

    return 0;
}
