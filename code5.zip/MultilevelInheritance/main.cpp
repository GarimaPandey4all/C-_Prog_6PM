#include <iostream>

using namespace std;

class Parent
{
public:
    int parent;
};

class Child1 : public Parent{
public:
    int child1;
};

class Child2 : public Child1
{
public:
    int child2;
};

int main()
{
    Child2 obj;

    obj.child1 = 10;
    obj.child2 = 20;
    obj.parent = 30;

    cout<<"Child - 1 "<<obj.child1<<endl;
    cout<<"Child - 2 "<<obj.child2<<endl;
    cout<<"Parent "<<obj.parent<<endl;

    return 0;
}
