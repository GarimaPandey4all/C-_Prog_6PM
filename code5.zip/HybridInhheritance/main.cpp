#include <iostream>

using namespace std;

//Hybrid = Heirarchical + Multiple

class Vehicle {
public:
    Vehicle()
    {
        cout<<"This is Vehicle Class"<<endl;
    }
};

class FourWheeler {
  public:
    FourWheeler()
    {
        cout<<"This is FourWheeler Class"<<endl;
    }
};

//Multiple Inheritance
class Car : public Vehicle, public FourWheeler
{
   public:
    Car()
    {
        cout<<"This is Car Class"<<endl;
    }
};

//Heirarchical Inheritance
class Bus : public Vehicle {

public:
    Bus()
    {
        cout<<"This is Bus Class"<<endl;
    }
};


int main()
{
    Car obj1;
    Bus obj2;

    return 0;
}
