#include <iostream>

using namespace std;

/*
    Inheritance: code reuseability

    Parent - Child Relationship

    Parent / Base Class
    Child / Derived Class

    Inheritance has 5 Types:

    1. Single Inheritance
    2. Mutltiple Inheritance
    3. Multilevel Inheritance
    4. Heirarchical Inheritance
    5. Hybrid Inheritance

*/

//Single Inheritance
//Parent Class
class Human
{
public:
    Human()
    {
        cout<<"This is Parent Class"<<endl;
    }
};

//Child Class
//Inheritance- : public Human
class Person : public Human
{
public:
    Person()
    {
        cout<<"This is Child Class"<<endl;
    }
};

int main()
{
    Person obj;

    return 0;
}
