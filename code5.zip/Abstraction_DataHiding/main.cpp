#include <iostream>

using namespace std;

//Data Hiding
class Abstraction{

private:
    int a, b;
public:
    //setter
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    //getter
    void getData()
    {
        cout<<a<<endl;
        cout<<b<<endl;
    }

};

int main()
{
    Abstraction obj;
    obj.setData(30, 70);
    obj.getData();

    return 0;
}
