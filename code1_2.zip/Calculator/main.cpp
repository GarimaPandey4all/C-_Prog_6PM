#include <iostream>

using namespace std;

class Calc {

public:
    int a, b; // data member /  instance variables

    void getData()
    {
        cout<<"Enter any value for a and b:";
        cin>>a>>b;
    }

    void showData()
    {
        cout<<"Addition: "<<(a + b)<<endl;
        cout<<"Subtraction: "<<(a - b)<<endl;
        cout<<"Division: "<<(a / b)<<endl;
        cout<<"Multiplication: "<<(a * b)<<endl;
    }
};


int main()
{
    Calc obj;
    obj.getData();
    obj.showData();

    return 0;
}
