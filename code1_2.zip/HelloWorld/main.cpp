#include <iostream> // Pre-Processor Directive

/*
    iostream:
    Input/Output Stream(flow of data)

    printf in C
    cout<< in C++

    scanf in C
    cin>> in C++

    \n - new line
    endl - new line
*/

using namespace std;

int main()
{
    //std::cout << "Hello \n world!" << std::endl; // :: - scope resolution operator

    cout<<"Hello "<<endl<<"World !";
    return 0;
}
