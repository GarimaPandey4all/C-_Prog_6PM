#include <iostream>

using namespace std;

class HelloWorld {

    /*
    class:

    1. Data Member / Instance(object) Variables
    2. Member Function

    Access Modifier / Specifier
    1. private (default)
    2. public
    3. protected

    */

public:
    //Member function/Method
    void showData()
    {
        cout<<"Hello World"<<endl;
        cout<<"How are you?";
    }

};


int main()
{
    HelloWorld obj;
    HelloWorld obj2;

    obj.showData();
    obj2.showData();

    return 0;
}
