#include <iostream>

using namespace std;

class Hello
{
public:
    int a, b;

    //default constructor
    Hello()
    {
        a = 10;
        b = 20;
    }

    void display()
    {
        cout<<a<<endl;
        cout<<b<<endl;
    }
};

int main()
{
    Hello h;
    h.display();

    return 0;
}
