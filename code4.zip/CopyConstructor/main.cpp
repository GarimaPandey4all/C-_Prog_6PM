#include <iostream>

using namespace std;

class CC
{
public:
    int a;

    CC(int x)
    {
        a = x;
    }

    CC(CC &t) // copy constructor
    {
        a = t.a; // a = 10
    }

};

int main()
{
    CC obj1(10);

    CC obj2(obj1); // called copy constructor

    cout<<"A of obj2 is: "<<obj2.a<<endl;

    return 0;
}
