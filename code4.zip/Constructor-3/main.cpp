#include <iostream>

using namespace std;

class PC{
public:
    int a, b;

    //Parameterized Constructor
    PC(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<a<<endl;
        cout<<b<<endl;
    }

};

int main()
{
    PC obj(10, 20); // calling of param constructor
    obj.showData();

    return 0;
}
