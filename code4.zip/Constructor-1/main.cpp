#include <iostream>

using namespace std;

/*
    Constructor: it is also a method but special type method
    It is used to initialize the instance variables.
    When we create / construct the object of the class then constructor automatically calls itself.

    constructor
    1. default constructor
    2. param constructor
    3. copy constructor

*/

class Example {
public:
    Example()
    {
        cout<<"Constructor";
    }
};

int main()
{
    Example obj;

    return 0;
}
