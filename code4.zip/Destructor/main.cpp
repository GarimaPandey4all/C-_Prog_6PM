#include <iostream>

using namespace std;

class HelloWorld {

public:
    //constructor
    HelloWorld()
    {
        cout<<"HelloWorld"<<endl;
    }

    //destructor
    ~HelloWorld() // ~ tilte
    {
        cout<<"Destructor"<<endl;
    }
};


int main()
{
    HelloWorld obj;

    return 0;
}
