#include <iostream>

using namespace std;

//Encapsulation - class is the example of encapsulation
// class/encapsulation: wrap all the variables and methods into a single unit.

class Encapsulation
{
public:

    int a, b;

    Encapsulation(int a, int b)
    {
        this->a = a;
        this->b = b;
    }

    void display()
    {
        cout<<a<<endl;
        cout<<b<<endl;
    }

};

int main()
{
    Encapsulation obj(10, 30);
    obj.display();

    return 0;
}
